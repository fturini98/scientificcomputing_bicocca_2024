# BicoccaCoursePython2024
Python package to solve the exercices of the Bicocca's phD python course.
The python package as a module for each lesson:
- Lesson 01 module ([prima_lezione](#prima_lezione))
- Lesson 02 module ([seconda_lezione](#seconda_lezione))
- Lesson 03 module ([terza_lezione](#terza_lezione))
- Lesson 04 module ([quarta_lezione](#quarta_lezione))
- [Lesson 08](#lesson-08) has no module (test, and package deployment)


## prima_lezione

## seconda_lezione

## terza_lezione

## quarta_lezione

## Lesson 08
The last lessons is about building a package and after **testing** deploy it.
I've done the exercices about:
- the tests (**Q2: My own test**)
- and the deployment (**Q1: I love pip**)
### Tests' exercice (Q2: My own test)
For the test's exercice I wrote a class ([TestBicoccaCoursePython2024](test/ottava_lezione_test.py)) with 4 methods':

- ***test_np_power***: Tests that in the whole code there is no np.power(10.,x), without the dot. This is usefull because some numpy version (e.g., those used with numba or TensorFlow) dosen't convert the 10 to a float indroducing a bug for the power of 10.

- tests for the [Game_life](src/BicoccaCoursePython2024/seconda_lezione.py) class:

    - ***test_default_initial_condition***: tests that the default intitial condition are the ones expected.

    - ***test_gen1***: tests that the first generation is the one that is excpected.

    - ***test_gen_10***: tests that the 10 gneration still the one obtained in the first run of the code. To do that the method uses the grid snapshot [PoP10_GameOfLife.npy](test/PoP10_GameOfLife.npy).

after that, trought the GitHub acitons ([Lezione8_tests.yml](../../.github/workflows/Lezione8_tests.yml)), I mange the continuos integration to verify that the code will pass the test at every push. If the code dosen't pass the tests is not possible to make the pull request over the GitHub's main branch (which is a protected by the rules set on the site).

### Deployment